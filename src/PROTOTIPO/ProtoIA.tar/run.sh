#!/bin/bash

clips -f ./JuegosDePruebas/run.clp