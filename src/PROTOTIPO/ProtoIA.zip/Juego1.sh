#!/bin/bash

clips -f ./JuegosDePruebas/Juego1.clp